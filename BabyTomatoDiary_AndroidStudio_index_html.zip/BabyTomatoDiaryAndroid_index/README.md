# Baby Tomato Diary — Android Studio

This is a WebView Android app whose actual diary interface is:
app/src/main/assets/index.html

Open the project root in Android Studio, sync Gradle, then Build > Build APK(s).

The HTML/JavaScript app stores diary data locally through WebView DOM storage.
